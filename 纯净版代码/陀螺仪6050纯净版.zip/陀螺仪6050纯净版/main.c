#include  "systemInit.h"
#include  <uart.h>
#include  <ctype.h>
#include  <string.h>
#include  "uartGetPut.h"
#include  <stdio.h>
#include  <timer.h>
#include  <adc.h>
#include  <stdio.h>

#define  PART_LM3S1138
#include  <pin_map.h>

unsigned char Re_buf[11],counter=0;
unsigned char ucStra[6],ucStrw[6],ucStrAngle[6];
float Value[9];

void delay(int a){
  int x,y;
  for(x=0;x<a;x++)
    for(y=0;y<255;y++);
}


void DataTreating()
{
  //float Value[8];
  //    char a[40];
  //    char b[40];
  char c[40];
  
  Value[0] = ((short)(ucStra[1]<<8| ucStra[0]))/32768.0*16;
  Value[1] = ((short)(ucStra[3]<<8| ucStra[2]))/32768.0*16;
  Value[2] = ((short)(ucStra[5]<<8| ucStra[4]))/32768.0*16;
  Value[3] = ((short)(ucStrw[1]<<8| ucStrw[0]))/32768.0*2000;
  Value[4] = ((short)(ucStrw[3]<<8| ucStrw[2]))/32768.0*2000;
  Value[5] = ((short)(ucStrw[5]<<8| ucStrw[4]))/32768.0*2000;
  
  Value[6] = ((short)(ucStrAngle[1]<<8| ucStrAngle[0]))/32768.0*180;
  Value[7] = ((short)(ucStrAngle[3]<<8| ucStrAngle[2]))/32768.0*180;
  Value[8] = ((short)(ucStrAngle[5]<<8| ucStrAngle[4]))/32768.0*180;
  //sprintf(a,"���ٶ���x:%.2f y:%.2f z:%.2f \r\n",Value[0],Value[1],Value[2]);
  //  sprintf(b,"���ٶ���x:%.2f y:%.2f z:%.2f \r\n",Value[3],Value[4],Value[5]);
  sprintf(c,"�Ƕ���x:%.2f y:%.2f z:%.2f \r\n",Value[6],Value[7],Value[8]);
  //uartPuts(a);
  // uartPuts(b);
  uartPuts(c);
  delay(10);
  
}

//  ��������������ڣ�
int main(void)
{
  //float Value[8];
  jtagWait();                                             //  ��ֹJTAGʧЧ����Ҫ��
  clockInit();                                            //  ʱ�ӳ�ʼ��������6MHz
  uartInit();                                             //  UART��ʼ��
  for (;;)
  {
    DataTreating();
  }
}


//  UART2�жϷ�����
void UART0_ISR(void)
{
  
  unsigned long ulStatus;
  
  ulStatus = UARTIntStatus(UART0_BASE, true);             //  ��ȡ��ǰ�ж�״̬
  UARTIntClear(UART0_BASE, ulStatus);                     //  ����ж�״̬
  
  if ((ulStatus & UART_INT_RX) || (ulStatus & UART_INT_RT))   //  ���ǽ����жϻ���
  {  for(;;)
  {Re_buf[counter]= uartGetc0();
  if(counter==0&&Re_buf[0]!=0x55) return;      //��0�����ݲ���֡ͷ
  
  counter++; 
  if(counter==11)             //���յ�11������
  {    
    counter=0;               //���¸�ֵ��׼����һ֡���ݵĽ���        
    switch(Re_buf [1])
    {
    case 0x51:
      ucStra[0]=Re_buf[2];
      ucStra[1]=Re_buf[3];
      ucStra[2]=Re_buf[4];
      ucStra[3]=Re_buf[5];
      ucStra[4]=Re_buf[6];
      ucStra[5]=Re_buf[7];
      break;
    case 0x52:	 
      ucStrw[0]=Re_buf[2];
      ucStrw[1]=Re_buf[3];
      ucStrw[2]=Re_buf[4];
      ucStrw[3]=Re_buf[5];
      ucStrw[4]=Re_buf[6];
      ucStrw[5]=Re_buf[7];
      break;
    case 0x53: 
      ucStrAngle[0]=Re_buf[2];
      ucStrAngle[1]=Re_buf[3];
      ucStrAngle[2]=Re_buf[4];
      ucStrAngle[3]=Re_buf[5];
      ucStrAngle[4]=Re_buf[6];
      ucStrAngle[5]=Re_buf[7];	
      break;
    }
    //DataTreating();
    
  }
  break;
  
  }
  }
}

